import { scanPurchaseInvoiceWithGemini } from '../src/lib/ai-invoice-scanner';
import dotenv from 'dotenv';
dotenv.config();

// Create a simple SVG rendered as base64 representing a medical bill
const sampleMedicalInvoiceSvg = `
<svg width="800" height="600" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="#ffffff"/>
  <text x="50" y="50" font-family="Arial" font-size="20" font-weight="bold">CITY HEALTH HOSPITAL PHARMACY WHOLESALE</text>
  <text x="50" y="80" font-family="Arial" font-size="14">GSTIN: 32AABCU9603R1ZM | Invoice: HOSP-2026-904 | Date: 2026-09-18</text>
  <line x1="50" y1="100" x2="750" y2="100" stroke="#000000" stroke-width="2"/>
  
  <text x="50" y="130" font-family="Arial" font-size="14" font-weight="bold">Item Description</text>
  <text x="350" y="130" font-family="Arial" font-size="14" font-weight="bold">Batch</text>
  <text x="450" y="130" font-family="Arial" font-size="14" font-weight="bold">Exp Date</text>
  <text x="550" y="130" font-family="Arial" font-size="14" font-weight="bold">Qty</text>
  <text x="650" y="130" font-family="Arial" font-size="14" font-weight="bold">Rate (Rs)</text>
  
  <text x="50" y="160" font-family="Arial" font-size="13">Paracetamol 500mg (10x10 Box)</text>
  <text x="350" y="160" font-family="Arial" font-size="13">PCM-204</text>
  <text x="450" y="160" font-family="Arial" font-size="13">2028-10-31</text>
  <text x="550" y="160" font-family="Arial" font-size="13">10 BOX</text>
  <text x="650" y="160" font-family="Arial" font-size="13">350.00</text>
  
  <text x="50" y="190" font-family="Arial" font-size="13">Amoxicillin 500mg Capsules</text>
  <text x="350" y="190" font-family="Arial" font-size="13">AMX-881</text>
  <text x="450" y="190" font-family="Arial" font-size="13">2027-06-30</text>
  <text x="550" y="190" font-family="Arial" font-size="13">5 BOX</text>
  <text x="650" y="190" font-family="Arial" font-size="13">620.00</text>
  
  <line x1="50" y1="220" x2="750" y2="220" stroke="#000000" stroke-width="1"/>
  <text x="500" y="250" font-family="Arial" font-size="14">Subtotal Taxable: Rs 6600.00</text>
  <text x="500" y="275" font-family="Arial" font-size="14">CGST @ 6%: Rs 396.00</text>
  <text x="500" y="300" font-family="Arial" font-size="14">SGST @ 6%: Rs 396.00</text>
  <text x="500" y="330" font-family="Arial" font-size="16" font-weight="bold">Net Total: Rs 7392.00</text>
</svg>
`;

const base64Png = Buffer.from(sampleMedicalInvoiceSvg).toString('base64');

async function run() {
  console.log('Sending test hospital bill to Gemini 2.5 Flash with the new key...');
  try {
    const result = await scanPurchaseInvoiceWithGemini(
      base64Png,
      'image/svg+xml',
      process.env.GOOGLE_GENERATIVE_AI_API_KEY
    );
    console.log('SUCCESSFUL EXTRACTION:');
    console.log(JSON.stringify(result, null, 2));
  } catch (err) {
    console.error('OCR test failed:', err);
  }
}

run();
