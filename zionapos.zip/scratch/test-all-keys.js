const fs = require('fs');
const files = [
  'c:/2035-HMS/SAAS_ERP/.env',
  'c:/2035-HMS/ZIONA_HOSPITAL/.env',
  'c:/2035-HMS/.env.globalmedicare',
  'c:/2035-HMS/SmartVyapar/.env'
];

const keys = new Set();
for (const f of files) {
  if (fs.existsSync(f)) {
    const content = fs.readFileSync(f, 'utf8');
    const lines = content.split('\n');
    for (const l of lines) {
      if (/GOOGLE_GENERATIVE_AI_API_KEY/i.test(l)) {
        const val = l.split('=')[1]?.trim().replace(/^["']|["']$/g, '');
        if (val) keys.add(val);
      }
    }
  }
}

async function testKeys() {
  console.log('Unique keys found:', keys.size);
  for (const k of keys) {
    console.log('Testing key ending in ...' + k.slice(-6));
    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${k}`);
      const data = await res.json();
      if (data.models) {
        console.log('Key is valid! Available models count:', data.models.length);
        // Test generation
        const genRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${k}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ parts: [{ text: 'ping' }] }] })
        });
        const genData = await genRes.json();
        if (genData.candidates) {
          console.log('ACTIVE WORKING KEY CONFIRMED! Value:', k);
        } else {
          console.log('Generation error with key:', JSON.stringify(genData));
        }
      } else {
        console.log('Key invalid:', JSON.stringify(data));
      }
    } catch(err) {
      console.error('Fetch error:', err.message);
    }
  }
}

testKeys();
