import { GoogleGenerativeAI } from "@google/generative-ai";
import * as dotenv from "dotenv";
dotenv.config();

async function main() {
  const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY;
  console.log("API Key present:", !!apiKey, apiKey ? apiKey.substring(0, 8) + "..." : "none");

  if (!apiKey) return;
  const genAI = new GoogleGenerativeAI(apiKey);

  const candidateModels = [
    "gemini-1.5-flash-latest",
    "gemini-2.0-flash",
    "gemini-2.5-flash",
    "gemini-1.5-pro",
    "gemini-1.5-flash-8b",
    "gemini-1.5-flash"
  ];

  for (const m of candidateModels) {
    try {
      console.log(`Testing model: ${m}...`);
      const model = genAI.getGenerativeModel({ model: m });
      const result = await model.generateContent("Hi, say OK");
      console.log(`SUCCESS with ${m}:`, result.response.text().trim());
      break;
    } catch (err: any) {
      console.log(`FAILED with ${m}:`, err.message?.substring(0, 120));
    }
  }
}

main().catch(console.error);
