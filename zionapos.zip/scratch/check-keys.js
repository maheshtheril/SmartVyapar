const fs = require('fs');
const files = [
  'c:/2035-HMS/SAAS_ERP/.env',
  'c:/2035-HMS/SAAS_ERP/.env.production',
  'c:/2035-HMS/SAAS_ERP/.env.vercel',
  'c:/2035-HMS/ZIONA_HOSPITAL/.env',
  'c:/2035-HMS/.env.globalmedicare',
  'c:/2035-HMS/SmartVyapar/.env',
  'c:/2035-HMS/SmartVyapar/.env.local'
];

for (const f of files) {
  if (fs.existsSync(f)) {
    const content = fs.readFileSync(f, 'utf8');
    const lines = content.split('\n');
    for (const l of lines) {
      if (/GEMINI|GOOGLE/i.test(l) && /KEY/i.test(l)) {
        console.log(f, ':', l.trim().substring(0, 30) + '...');
      }
    }
  }
}
