const { GoogleGenerativeAI } = require('@google/generative-ai');
const fs = require('fs');
const dotenv = require('dotenv');
if (fs.existsSync('.env')) {
  dotenv.config({ path: '.env' });
}

const key = process.env.GOOGLE_GENERATIVE_AI_API_KEY;
const genAI = new GoogleGenerativeAI(key);

async function test() {
  const models = ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-3.6-flash', 'gemini-3.7-flash'];
  for (const m of models) {
    try {
      console.log(`Testing model: ${m}...`);
      const model = genAI.getGenerativeModel({ model: m });
      const res = await model.generateContent('Say hello in 3 words');
      console.log(`SUCCESS [${m}]:`, res.response.text().trim());
      return;
    } catch(err) {
      console.error(`FAILED [${m}]:`, err.message);
    }
  }
}

test();
