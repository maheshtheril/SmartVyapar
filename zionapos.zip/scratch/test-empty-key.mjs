import { cleanHumanReadableAiError, scanPurchaseInvoiceWithGemini } from '../src/lib/ai-invoice-scanner';

async function test() {
  process.env.GOOGLE_GENERATIVE_AI_API_KEY = "";
  try {
    await scanPurchaseInvoiceWithGemini("test", "image/jpeg");
  } catch(e) {
    console.log("Empty key error:", cleanHumanReadableAiError(e));
  }
}
test();
