import { cleanHumanReadableAiError } from '../src/lib/ai-invoice-scanner';

const err1 = new Error('[GoogleGenerativeAI Error]: Error fetching from https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-latest:generateContent: [403 Forbidden] Your project has been denied access. Please contact support.');
console.log('Case 1:', cleanHumanReadableAiError(err1));

const err2 = { message: 'Failed to scan invoice' };
console.log('Case 2:', cleanHumanReadableAiError(err2));

const err3 = new Error('[GoogleGenerativeAI Error]: Error fetching from https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-latest:generateContent: [403]');
console.log('Case 3:', cleanHumanReadableAiError(err3));
