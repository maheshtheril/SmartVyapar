import { NextRequest, NextResponse } from "next/server";
import { prisma, DEFAULT_TX_OPTIONS } from "@/lib/prisma";
import { GstCalculator } from "@/lib/gst";
import { UpiService } from "@/lib/upi";
import { PaymentStatus, PaymentMode, StockLogType } from "@prisma/client";
import { requireSession } from "@/lib/auth";
import { generateNextInvoiceNumber } from "@/lib/invoice-sequence";
import { validateBody } from "@/lib/validation";
import { CreateInvoiceSchema } from "@/lib/schemas/invoice";

export const dynamic = "force-dynamic";

// GET /api/invoices - Fetch real invoices from Neon DB
export async function GET(req: NextRequest) {
  try {
    const session = await requireSession(req);
    const tenantId = session.tenantId;

    const { searchParams } = new URL(req.url);
    const query = searchParams.get("q")?.toLowerCase();
    const status = searchParams.get("status")?.toUpperCase();

    const where: any = {
      tenantId,
    };

    if (status && (status === "PAID" || status === "PARTIAL" || status === "UNPAID")) {
      where.paymentStatus = status as PaymentStatus;
    }

    if (query) {
      where.OR = [
        { invoiceNumber: { contains: query, mode: "insensitive" } },
        { customerName: { contains: query, mode: "insensitive" } },
        { customerPhone: { contains: query } },
      ];
    }

    const invoices = await prisma.invoice.findMany({
      where,
      include: {
        items: true,
      },
      orderBy: { createdAt: "desc" },
    });

    // Compute live metrics using database aggregations (OOM safe)
    const todayStr = new Date().toISOString().split("T")[0];
    const todayStart = new Date(`${todayStr}T00:00:00.000Z`);
    const todayEnd = new Date(`${todayStr}T23:59:59.999Z`);

    const [invAll, invToday, cnAll, cnToday] = await Promise.all([
      prisma.invoice.aggregate({
        where: { tenantId, einvoiceStatus: { not: "CANCELLED" } },
        _sum: { dueAmount: true, cgstAmount: true, sgstAmount: true, igstAmount: true },
      }),
      prisma.invoice.aggregate({
        where: { tenantId, einvoiceStatus: { not: "CANCELLED" }, invoiceDate: { gte: todayStart, lte: todayEnd } },
        _sum: { totalAmount: true },
      }),
      prisma.creditNote.aggregate({
        where: { tenantId },
        _sum: { cgstAmount: true, sgstAmount: true, igstAmount: true },
      }),
      prisma.creditNote.aggregate({
        where: { tenantId, creditNoteDate: { gte: todayStart, lte: todayEnd } },
        _sum: { totalAmount: true },
      })
    ]);

    const todaySales = Number(invToday._sum.totalAmount || 0) - Number(cnToday._sum.totalAmount || 0);
    const totalUdhar = Number(invAll._sum.dueAmount || 0);
    const totalOutputCgst = Number(invAll._sum.cgstAmount || 0) - Number(cnAll._sum.cgstAmount || 0);
    const totalOutputSgst = Number(invAll._sum.sgstAmount || 0) - Number(cnAll._sum.sgstAmount || 0);
    const totalOutputIgst = Number(invAll._sum.igstAmount || 0) - Number(cnAll._sum.igstAmount || 0);

    const lowStockCount = await prisma.product.count({
      where: {
        tenantId,
        currentStock: { lte: prisma.product.fields.minStockAlert },
      },
    });

    const tenant = await prisma.tenant.findUnique({
      where: { id: tenantId },
      select: {
        businessName: true,
        legalName: true,
        logoUrl: true,
        gstin: true,
        stateCode: true,
        phone: true,
        address: true,
        upiId: true,
      },
    });

    return NextResponse.json({
      success: true,
      tenant,
      invoices,
      metrics: {
        todaySales,
        totalUdhar,
        netGstOutput: totalOutputCgst + totalOutputSgst + totalOutputIgst,
        lowStockCount,
      },
    });
  } catch (error: any) {
    console.error("Error fetching invoices:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// POST /api/invoices - Create real invoice & perform atomic stock deduction
export async function POST(req: NextRequest) {
  try {
    const session = await requireSession(req);
    const tenantId = session.tenantId;

    const body = await req.json();
    const validation = validateBody(CreateInvoiceSchema, body);
    if (!validation.success) {
      return validation.response;
    }
    const data = validation.data;

    // Fetch tenant for stateCode (needed for GST jurisdiction)
    const tenant = await prisma.tenant.findUnique({ where: { id: tenantId } });
    if (!tenant) {
      return NextResponse.json({ error: "Tenant not found" }, { status: 404 });
    }

    const isInterState = data.customerStateCode !== tenant.stateCode;

    // Fetch product details for all items to verify stock, prices & recipes
    const productIds = data.items.map((i) => i.productId);
    const dbProducts = await prisma.product.findMany({
      where: { id: { in: productIds }, tenantId },
      include: {
        recipeIngredients: {
          include: { ingredient: true },
        },
      },
    });
    const productMap = new Map(dbProducts.map((p) => [p.id, p]));

    // Atomic transaction: Create Invoice, Line Items, Deduct Stock, Record Stock Logs
    const result = await prisma.$transaction(async (tx) => {
      // 1. Generate Invoice Number atomically (race-condition safe)
      const { invoiceNumber } = await generateNextInvoiceNumber(tx, { tenantId });

      let subtotal = 0;
      let totalCgst = 0;
      let totalSgst = 0;
      let totalIgst = 0;

      const processedItems = [];

      for (const item of data.items) {
        const product = productMap.get(item.productId);
        if (!product) {
          throw new Error(`Product ID ${item.productId} not found`);
        }

        const qty = Number(item.quantity);
        const unitSold = item.unitSold || product.baseUnit;
        const isAlt = product.hasAltUnit && product.altUnit && unitSold === product.altUnit;
        const conversionFactor = isAlt && product.conversionFactor ? Number(product.conversionFactor) : 1.0;
        const baseQty = Number((qty * conversionFactor).toFixed(3));

        const defaultPrice = isAlt && product.sellingPricePerAlt
          ? Number(product.sellingPricePerAlt)
          : Number(product.sellingPrice) * (isAlt ? conversionFactor : 1);
        
        const unitPrice = item.unitPrice !== undefined ? Number(item.unitPrice) : defaultPrice;
        const lineTaxable = unitPrice * qty;
        subtotal += lineTaxable;

        const tax = GstCalculator.calculate(
          lineTaxable,
          Number(product.gstRate),
          tenant.stateCode,
          data.customerStateCode,
          tenant.isComposition
        );

        totalCgst += tax.cgstAmount;
        totalSgst += tax.sgstAmount;
        totalIgst += tax.igstAmount;

        processedItems.push({
          productId: product.id,
          productName: product.name,
          hsnCode: product.hsnCode,
          unitSold,
          quantity: qty,
          conversionFactor,
          baseQuantity: baseQty,
          unitPrice,
          gstRate: Number(product.gstRate),
          cgstAmount: tax.cgstAmount,
          sgstAmount: tax.sgstAmount,
          igstAmount: tax.igstAmount,
          batchId: item.batchId || null,
          batchNumber: item.batchNumber || null,
          lineTotal: tax.totalAmount,
        });

        // Batch Stock Depletion & Verification
        if (item.batchId) {
          const batch = await tx.batch.findUnique({ where: { id: item.batchId } });
          if (!batch || batch.tenantId !== tenantId) {
            throw new Error(`Batch not found or unauthorized for product ${product.name}`);
          }
          if (Number(batch.currentStock) < baseQty) {
            throw new Error(`Insufficient stock in batch ${batch.batchNumber} for ${product.name}`);
          }
          const updatedBatch = await tx.batch.update({
            where: { id: item.batchId },
            data: { currentStock: { decrement: baseQty } },
          });
          
          if (Number(updatedBatch.currentStock) < 0) {
            throw new Error(`Insufficient stock for batch ${updatedBatch.batchNumber}`);
          }
        }

        // Stock Depletion: Check if Product has Recipe Items (Finished Good / Restaurant Dish)
        if (product.recipeIngredients && product.recipeIngredients.length > 0) {
          // Recipe Item: Auto-deplete raw ingredients (Backflushing)
          for (const recipeItem of product.recipeIngredients) {
            const rawReqPerPortion = Number(recipeItem.quantityRequired);
            const wasteFactor = 1 + (Number(recipeItem.wastePercentage || 0) / 100);
            const totalRawConsumed = Number((qty * rawReqPerPortion * wasteFactor).toFixed(3));

            const ingredient = await tx.product.findUnique({ where: { id: recipeItem.ingredientId } });
            if (!ingredient || Number(ingredient.currentStock) < totalRawConsumed) {
               throw new Error(`Insufficient stock for ingredient ${ingredient?.name || recipeItem.ingredientId} needed for ${product.name}`);
            }

            // Decrement raw material stock
            const updatedIng = await tx.product.update({
              where: { id: recipeItem.ingredientId },
              data: { currentStock: { decrement: totalRawConsumed } },
            });
            if (Number(updatedIng.currentStock) < 0) {
              throw new Error(`Insufficient stock for ingredient ID ${recipeItem.ingredientId}`);
            }

            // Log raw material consumption audit
            await tx.stockLog.create({
              data: {
                tenantId,
                productId: recipeItem.ingredientId,
                changeQty: -totalRawConsumed,
                type: StockLogType.CONSUMPTION_OUT,
                referenceId: invoiceNumber,
                note: `Recipe Depletion: ${totalRawConsumed} consumed for ${qty} ${product.name} (Bill #${invoiceNumber})`,
              },
            });
          }
        } else {
          // Standard Retail Item: Direct stock deduction
          const currentProd = await tx.product.findUnique({ where: { id: product.id } });
          if (!currentProd || Number(currentProd.currentStock) < baseQty) {
            throw new Error(`Insufficient stock for product ${product.name}`);
          }

          const updatedProd = await tx.product.update({
            where: { id: product.id },
            data: { currentStock: { decrement: baseQty } },
          });
          if (Number(updatedProd.currentStock) < 0) {
            throw new Error(`Insufficient global stock for ${product.name}`);
          }

          // Audit Stock Log
          await tx.stockLog.create({
            data: {
              tenantId,
              productId: product.id,
              changeQty: -baseQty,
              type: StockLogType.SALE_OUT,
              referenceId: invoiceNumber,
              note: `Sold ${qty} ${unitSold} (${baseQty}) to ${data.customerName}${item.batchNumber ? ` [Batch: ${item.batchNumber}]` : ''} (Bill #${invoiceNumber})`,
            },
          });
        }
      }

      const totalTax = totalCgst + totalSgst + totalIgst;
      const grossAmount = Number((subtotal + totalTax).toFixed(2));

      // Upsert Customer first to check loyalty balance
      let customer = await tx.customer.findFirst({
        where: { tenantId, phone: data.customerPhone },
      });

      if (!customer) {
        customer = await tx.customer.create({
          data: {
            tenantId,
            name: data.customerName,
            phone: data.customerPhone,
            stateCode: data.customerStateCode,
            outstandingBalance: 0,
            loyaltyPoints: 0,
          },
        });
      }

      // 1. Process Loyalty Points Redemption (1 point = ₹1 discount)
      const requestedRedeem = Number(data.loyaltyPointsToRedeem || 0);
      const pointsToRedeem = Math.min(
        Math.max(0, requestedRedeem),
        customer.loyaltyPoints || 0,
        Math.floor(grossAmount) // Cannot redeem more than total bill
      );
      const loyaltyDiscountAmount = pointsToRedeem;
      const totalAmount = Number(Math.max(0, grossAmount - loyaltyDiscountAmount).toFixed(2));
      let submittedPaid = Number(data.paidAmount || 0);
      if (submittedPaid > totalAmount) {
        throw new Error(`Paid amount (₹${submittedPaid}) cannot exceed total invoice amount (₹${totalAmount})`);
      }
      const finalPaid = data.paymentStatus === "PAID" ? totalAmount : submittedPaid;
      const dueAmount = Number(Math.max(0, totalAmount - finalPaid).toFixed(2));

      // 2. Process Loyalty Points Accrual (1 point per ₹100 billed)
      const pointsEarned = Math.floor(totalAmount / 100);

      // Net point adjustment on customer: -redeemed + earned
      const netPointsChange = pointsEarned - pointsToRedeem;

      // Update customer outstanding balance and loyalty points atomically
      const customerUpdateData: any = {};
      if (dueAmount > 0) {
        customerUpdateData.outstandingBalance = { increment: dueAmount };
      }
      if (netPointsChange !== 0) {
        customerUpdateData.loyaltyPoints = { increment: netPointsChange };
      }
      if (Object.keys(customerUpdateData).length > 0) {
        customer = await tx.customer.update({
          where: { id: customer.id },
          data: customerUpdateData,
        });
      }

      const upiUri = UpiService.generateUpiUri({
        upiId: tenant.upiId,
        payeeName: tenant.businessName,
        amount: dueAmount > 0 ? dueAmount : totalAmount,
        invoiceNumber,
        note: `Invoice ${invoiceNumber} for ${data.customerName}`,
      });

      // Create Invoice
      const invoice = await tx.invoice.create({
        data: {
          tenantId,
          invoiceNumber,
          customerId: customer.id,
          customerName: data.customerName,
          customerPhone: data.customerPhone,
          customerGstin: data.customerGstin,
          customerStateCode: data.customerStateCode,
          isInterState,
          subtotal,
          cgstAmount: totalCgst,
          sgstAmount: totalSgst,
          igstAmount: totalIgst,
          totalTax,
          totalAmount,
          paidAmount: finalPaid,
          dueAmount,
          paymentStatus: data.paymentStatus as PaymentStatus,
          paymentMode: data.paymentMode as PaymentMode,
          upiUri,
          notes: data.notes,
          loyaltyPointsEarned: pointsEarned,
          loyaltyPointsRedeemed: pointsToRedeem,
          loyaltyDiscountAmount,
          items: {
            create: processedItems,
          },
        },
        include: {
          items: true,
        },
      });

      // Log Loyalty Transactions if points were redeemed or earned
      if (pointsToRedeem > 0) {
        await tx.loyaltyTransaction.create({
          data: {
            tenantId,
            customerId: customer.id,
            invoiceId: invoice.id,
            pointsChange: -pointsToRedeem,
            balanceAfter: customer.loyaltyPoints - pointsEarned,
            type: "REDEEM",
            notes: `Redeemed ${pointsToRedeem} points (-₹${loyaltyDiscountAmount}) on Bill #${invoiceNumber}`,
          },
        });
      }

      if (pointsEarned > 0) {
        await tx.loyaltyTransaction.create({
          data: {
            tenantId,
            customerId: customer.id,
            invoiceId: invoice.id,
            pointsChange: pointsEarned,
            balanceAfter: customer.loyaltyPoints,
            type: "EARN",
            notes: `Earned ${pointsEarned} reward points on Bill #${invoiceNumber}`,
          },
        });
      }

      // 7. Automated Double-Entry Accounting
      const { postInvoiceJournalEntry } = await import("@/lib/accounting-mapper");
      await postInvoiceJournalEntry(tx, tenantId, invoice);

      return {
        ...invoice,
        customerLoyalty: {
          pointsRedeemed: pointsToRedeem,
          pointsEarned,
          currentBalance: customer.loyaltyPoints,
        },
      };
    }, DEFAULT_TX_OPTIONS);

    return NextResponse.json({ success: true, invoice: result });
  } catch (error: any) {
    console.error("Error creating invoice:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
