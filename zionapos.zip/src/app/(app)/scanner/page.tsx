import { redirect } from 'next/navigation';

export default function ScannerPage() {
  redirect('/inventory/purchase');
}
